<!DOCTYPE html>
<html>
<head>
    <title>Will Table 2 - PHP Nested Loop Random Numbers</title>
</head>
<body>

<!-- 
    Author: Will Cotton
    Course: CSD440
    Assignment: Module 1.2 - PHP Nested Loop Table
    Description: This program generates a 2D HTML table using PHP nested loops.
                 Random numbers are displayed in each cell.
                 Table tags are written in HTML, not echoed by PHP.
-->

<h2>PHP Generated Random Number Table</h2>

<table border="1" cellpadding="8" cellspacing="0">

<?php
// Outer loop controls table rows
for ($row = 0; $row < 5; $row++) {
?>
    <tr>
    <?php
    // Inner loop controls table columns
    for ($col = 0; $col < 5; $col++) {

        // Generate a random number between 1 and 100
        $randomNumber = rand(1, 100);
    ?>
        <td><?php echo $randomNumber; ?></td>
    <?php
    }
    ?>
    </tr>
<?php
}
?>

</table>

</body>
</html>
