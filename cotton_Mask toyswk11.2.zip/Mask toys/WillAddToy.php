<?php

$conn = new mysqli("localhost", "student1", "pass", "baseball_01");

if ($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
    $vehicle_name = trim($_POST["vehicle_name"]);
    $character_name = trim($_POST["character_name"]);
    $release_year = $_POST["release_year"];
    $price_usd = $_POST["price_usd"];
    $notes = trim($_POST["notes"]);

    $sql = "INSERT INTO masktoys
            (vehicle_name, character_name, release_year, price_usd, notes)
            VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if ($stmt === false)
    {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param(
        "ssids",
        $vehicle_name,
        $character_name,
        $release_year,
        $price_usd,
        $notes
    );

    if ($stmt->execute())
    {
        $message = "Toy added successfully!";
    }
    else
    {
        $message = "Error adding toy: " . $stmt->error;
    }

    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Add Toy</title>
</head>

<body>

<h2>Add a Toy</h2>

<?php
if ($message != "")
{
    echo "<h3>" . htmlspecialchars($message) . "</h3>";
}
?>

<form method="post" action="WillAddToy.php">

    <label for="vehicle_name">Vehicle Name:</label>
    <input
        type="text"
        id="vehicle_name"
        name="vehicle_name"
        required>
    <br><br>

    <label for="character_name">Character Name:</label>
    <input
        type="text"
        id="character_name"
        name="character_name">
    <br><br>

    <label for="release_year">Release Year:</label>
    <input
        type="number"
        id="release_year"
        name="release_year"
        min="1900"
        max="2100">
    <br><br>

    <label for="price_usd">Price (USD):</label>
    <input
        type="number"
        id="price_usd"
        name="price_usd"
        min="0"
        step="0.01">
    <br><br>

    <label for="notes">Notes:</label><br>
    <textarea
        id="notes"
        name="notes"
        rows="4"
        cols="50"></textarea>
    <br><br>

    <input type="submit" value="Add Toy">

</form>

<br><br>

<a href="WillIndex.php">
    <button type="button">Return Home</button>
</a>

</body>
</html>

<?php
$conn->close();
?>
