<?php
/**
 * File Name: Will PDF.php
 * Author: Will Cotton
 * Course: CSD440
 * Module 8 Assignment
 * Purpose: Generate a PDF report containing all records
 * from the M.A.S.K. Toys database.
 */

require('fpdf/fpdf.php');

/**
 * Custom PDF Class
 */
class PDF extends FPDF
{
    /**
     * Page Header
     */
    function Header()
    {
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, 'M.A.S.K. Toys Database Report', 0, 1, 'C');
        $this->Ln(5);
    }

    /**
     * Page Footer
     */
    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);

        $this->Cell(
            0,
            10,
            'Page ' . $this->PageNo(),
            0,
            0,
            'C'
        );
    }
}

/**
 * Database Connection
 */
$conn = new mysqli(
    "localhost",
    "student1",
    "pass",
    "baseball_01"
);

if ($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}

/**
 * Retrieve Data
 */
$sql = "SELECT * FROM masktoys";
$result = $conn->query($sql);

/**
 * Create PDF
 */
$pdf = new PDF();
$pdf->AddPage();

/**
 * General Information Section
 */
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'General Information', 0, 1);

$pdf->SetFont('Arial', '', 11);

$pdf->MultiCell(
    0,
    6,
    "M.A.S.K. (Mobile Armored Strike Kommand) was a popular "
    . "toy line released in 1985. The franchise featured transforming "
    . "vehicles, heroes, villains, and special masks with unique powers. "
    . "This report displays all toy records currently stored in the "
    . "masktoys database table."
);

$pdf->Ln(5);

/**
 * Table Header
 */
$pdf->SetFont('Arial', 'B', 9);

$pdf->Cell(10, 10, 'ID', 1);
$pdf->Cell(28, 10, 'Vehicle', 1);
$pdf->Cell(38, 10, 'Character', 1);
$pdf->Cell(18, 10, 'Year', 1);
$pdf->Cell(20, 10, 'Price', 1);
$pdf->Cell(75, 10, 'Notes', 1);

$pdf->Ln();

/**
 * Table Data
 */
$pdf->SetFont('Arial', '', 8);

while ($row = $result->fetch_assoc())
{
    $pdf->Cell(10, 10, $row['toy_id'], 1);
    $pdf->Cell(28, 10, $row['vehicle_name'], 1);
    $pdf->Cell(38, 10, $row['character_name'], 1);
    $pdf->Cell(18, 10, $row['release_year'], 1);
    $pdf->Cell(20, 10, '$' . $row['price_usd'], 1);
    $pdf->Cell(75, 10, $row['notes'], 1);

    $pdf->Ln();
}

/**
 * Close Database Connection
 */
$conn->close();

/**
 * Display PDF
 */
$pdf->Output();
?>