<!DOCTYPE html>
<html>
<head>
    <title>Create MASK Toys Table</title>
</head>
<body>
<?php
$servername = "localhost";
$username = "student1";
$password = "pass";
$dbname = "baseball_01";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL to create table
$sql = "CREATE TABLE MASKToys (
    toy_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    vehicle_name VARCHAR(50) NOT NULL,
    character_name VARCHAR(50),
    release_year YEAR,
    price_usd DECIMAL(6,2),
    notes TEXT
)";

if ($conn->query($sql) === TRUE) {
    echo "<h3>Table MASKToys created successfully!</h3>";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>
</body>
</html>
