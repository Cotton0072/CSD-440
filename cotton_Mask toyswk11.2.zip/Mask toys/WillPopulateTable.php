<!DOCTYPE html>
<html>
<head>
    <title>Populate MASK Toys Table</title>
</head>
<body>
<?php
$servername = "localhost";
$username = "student1";
$password = "pass";
$dbname = "baseball_01";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prevent duplicate inserts
$check = $conn->query("SELECT COUNT(*) AS total FROM MASKToys");
$row = $check->fetch_assoc();

if ($row['total'] > 0) {
    echo "<h3>MASKToys already has data — no new rows inserted.</h3>";
    $conn->close();
    exit();
}

$sql = "INSERT INTO MASKToys (vehicle_name, character_name, release_year, price_usd, notes) VALUES
('Thunderhawk', 'Matt Trakker', 1985, 12.99, 'Transforms from car to jet'),
('Rhino', 'Bruce Sato / Matt Trakker', 1985, 24.99, 'Semi-truck with multiple battle modes'),
('Outlaw', 'Miles Mayhem / Nash Gorey', 1985, 22.99, 'Tanker truck with hidden cannon'),
('Switchblade', 'Miles Mayhem', 1985, 14.99, 'Helicopter that converts to jet mode')";

if ($conn->query($sql) === TRUE) {
    echo "<h3>MASKToys table populated successfully!</h3>";
} else {
    echo "Error inserting records: " . $conn->error;
}

$conn->close();
?>
</body>
</html>
