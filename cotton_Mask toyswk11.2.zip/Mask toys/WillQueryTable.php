<!DOCTYPE html>
<html>
<head>
    <title>Query MASK Toys Table</title>
    <style>
        table {
            border-collapse: collapse;
            width: 70%;
            margin: 20px auto;
        }
        th, td {
            border: 1px solid #444;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #ddd;
        }
    </style>
</head>
<body>
<?php
$servername = "localhost";
$username = "student1";
$password = "pass";
$dbname = "baseball_01";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT toy_id, vehicle_name, character_name, release_year, price_usd, notes FROM MASKToys";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2 style='text-align:center;'>Kenner M.A.S.K. Toy Line (1985)</h2>";
    echo "<table><tr><th>ID</th><th>Vehicle</th><th>Character</th><th>Year</th><th>Price (USD)</th><th>Notes</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["toy_id"]."</td><td>".$row["vehicle_name"]."</td><td>".$row["character_name"]."</td><td>".$row["release_year"]."</td><td>".$row["price_usd"]."</td><td>".$row["notes"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "<p style='text-align:center;'>No records found in MASKToys table.</p>";
}

$conn->close();
?>
</body>
</html>
