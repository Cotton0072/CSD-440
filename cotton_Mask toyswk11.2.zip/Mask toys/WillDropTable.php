<!DOCTYPE html>
<html>
<head>
    <title>Drop MASK Toys Table</title>
</head>
<body>
<?php
$servername = "localhost";
$username = "student1";
$password = "pass";
$dbname = "baseball_01";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "DROP TABLE IF EXISTS MASKToys";

if ($conn->query($sql) === TRUE) {
    echo "<h3>MASKToys table dropped successfully!</h3>";
} else {
    echo "Error dropping table: " . $conn->error;
}

$conn->close();
?>
</body>
</html>
