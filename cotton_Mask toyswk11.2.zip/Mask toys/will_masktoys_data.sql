-- Will Cotton
-- CSD440 Module 8 Assignment
-- Database: baseball_01
-- Table: masktoys
-- Purpose: Create and populate table for PHP integration

CREATE DATABASE IF NOT EXISTS baseball_01;
USE baseball_01;

DROP TABLE IF EXISTS masktoys;

CREATE TABLE masktoys (
    toy_id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_name VARCHAR(50),
    character_name VARCHAR(50),
    release_year INT,
    price_usd DECIMAL(5,2),
    notes TEXT
);

INSERT INTO masktoys (vehicle_name, character_name, release_year, price_usd, notes) VALUES
('Thunderhawk', 'Matt Trakker', 1985, 12.99, 'Transforms into a jet'),
('Rhino', 'Bruce Sato / Matt Trakker', 1985, 24.99, 'Semi-truck with detachable ATV'),
('Outlaw', 'Miles Mayhem / Nash Gorey', 1985, 22.99, 'Snake Oil tanker with hidden weapons'),
('Switchblade', 'Miles Mayhem', 1985, 14.99, 'Helicopter that converts to jet'),
('Condor', 'Brad Turner', 1985, 19.99, 'Motorcycle that becomes helicopter');
