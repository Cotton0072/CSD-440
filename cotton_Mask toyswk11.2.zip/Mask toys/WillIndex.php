<!DOCTYPE html>
<html>
<head>
    <title>Mask Toys Database</title>
</head>
<body>

    <h1>Mask Toys Database</h1>

  <ul>
    <li><a href="WillQueryTable.php">View All Toys</a></li>
    <li><a href="WillSearchToy.php">Search Toys</a></li>
    <li><a href="WillAddToy.php">Add New Toy<ul>

</body>
</html>