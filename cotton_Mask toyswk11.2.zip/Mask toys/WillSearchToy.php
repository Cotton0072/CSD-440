<?php
/*
*************************************************
File Name: WillSearchToy.php
Author: Will Cotton
Purpose: Search for toys in the masktoys table
*************************************************
*/

$conn = new mysqli("localhost", "student1", "pass", "baseball_01");

if ($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search Toys</title>
</head>

<body>

<h1>Search for a Toy</h1>

<form method="post">
    Vehicle Name:
    <input type="text" name="vehicle_name">
    <input type="submit" value="Search">
</form>

<br>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
    $vehicleName = $_POST["vehicle_name"];

    $sql = "SELECT *
            FROM masktoys
            WHERE vehicle_name LIKE '%$vehicleName%'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0)
    {
        echo "<h2>Search Results</h2>";

        while ($row = $result->fetch_assoc())
        {
            echo "<p>";
            echo "<strong>Toy ID:</strong> " . $row["toy_id"] . "<br>";
            echo "<strong>Vehicle Name:</strong> " . $row["vehicle_name"] . "<br>";
            echo "<strong>Character Name:</strong> " . $row["character_name"] . "<br>";
            echo "<strong>Release Year:</strong> " . $row["release_year"] . "<br>";
            echo "<strong>Price:</strong> $" . $row["price_usd"] . "<br>";
            echo "</p><hr>";
        }
    }
    else
    {
        echo "<p>No toys found.</p>";
    }
}

$conn->close();

?>

<br>

<p>
   <li><a href="WillIndex.php"Return to Home</a>
     <button type="button">Return Home</button>
</p>

</body>
</html>