<!DOCTYPE html>
<html>
<head>
    <title>Will's Form</title>
</head>
<body>

<h2>Enter Your Information</h2>

<form action="WillFormProcess.php" method="post">

    Full Name: <input type="text" name="fullname"><br><br>

    Email Address: <input type="email" name="email"><br><br>

    Age: <input type="number" name="age"><br><br>

    Favorite Meal:
    <select name="meal">
        <option value="">--Select--</option>
        <option value="Breakfast">Breakfast</option>
        <option value="Lunch">Lunch</option>
        <option value="Dinner">Dinner</option>
    </select><br><br>

    Satisfaction Level:
    <input type="radio" name="satisfaction" value="Good"> Good
    <input type="radio" name="satisfaction" value="Average"> Average
    <input type="radio" name="satisfaction" value="Poor"> Poor
    <br><br>

    Comments:<br>
    <textarea name="comments" rows="4" cols="40"></textarea><br><br>

    Visit Date: <input type="date" name="visitdate"><br><br>

    <input type="submit" value="Submit">

</form>

</body>
</html>
