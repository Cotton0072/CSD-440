<!DOCTYPE html>
<html>
<head>
    <title>Form Results</title>
</head>
<body>

<?php
// Collect form data safely
$fullname     = $_POST['fullname'] ?? '';
$email        = $_POST['email'] ?? '';
$age          = $_POST['age'] ?? '';
$meal         = $_POST['meal'] ?? '';
$satisfaction = $_POST['satisfaction'] ?? '';
$comments     = $_POST['comments'] ?? '';
$visitdate    = $_POST['visitdate'] ?? '';

// Error array
$errors = [];

// Validation checks
if (empty($fullname))     $errors[] = "Full Name is required.";
if (empty($email))        $errors[] = "Email is required.";
elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Email format is invalid.";
if (empty($age))          $errors[] = "Age is required.";
elseif (!is_numeric($age)) $errors[] = "Age must be a number.";
if (empty($meal))         $errors[] = "Meal selection is required.";
if (empty($satisfaction)) $errors[] = "Satisfaction level is required.";
if (empty($comments))     $errors[] = "Comments are required.";
if (empty($visitdate))    $errors[] = "Visit Date is required.";

// If errors exist, display them
if (!empty($errors)) {
    echo "<h2>Errors Found</h2>";
    echo "<ul>";
    foreach ($errors as $e) {
        echo "<li>$e</li>";
    }
    echo "</ul>";
    echo "<p><a href='WillForm.php'>Go back and correct the issues.</a></p>";
    exit;
}

// If no errors, display formatted table
?>

<h2>Form Submission Successful</h2>
<p>Below is the information you entered:</p>

<table border="1" cellpadding="8">
    <tr><td>Full Name</td><td><?php echo htmlspecialchars($fullname); ?></td></tr>
    <tr><td>Email</td><td><?php echo htmlspecialchars($email); ?></td></tr>
    <tr><td>Age</td><td><?php echo htmlspecialchars($age); ?></td></tr>
    <tr><td>Favorite Meal</td><td><?php echo htmlspecialchars($meal); ?></td></tr>
    <tr><td>Satisfaction Level</td><td><?php echo htmlspecialchars($satisfaction); ?></td></tr>
    <tr><td>Comments</td><td><?php echo nl2br(htmlspecialchars($comments)); ?></td></tr>
    <tr><td>Visit Date</td><td><?php echo htmlspecialchars($visitdate); ?></td></tr>
</table>

</body>
</html>
