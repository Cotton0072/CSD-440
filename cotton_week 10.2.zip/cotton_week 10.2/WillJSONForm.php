<?php
/*
    Name: Will Cotton
    Course: CSD 440 - Server-Side Scripting
    Assignment: Module 10 JSON Form
    Date: September 26, 2026
    File: WillJSONForm.php

   
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>JSON Student Form</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px;
            font-family: Arial, sans-serif;
            background-color: #eef2f7;
        }

        .container {
            max-width: 700px;
            margin: auto;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        h1 {
            text-align: center;
            color: #1f3c68;
        }

        .instructions {
            text-align: center;
            color: #555555;
        }

        .form-group {
            margin-bottom: 16px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        input {
            display: block;
            width: 100%;
            padding: 10px;
            border: 1px solid #777777;
            border-radius: 5px;
            font-size: 16px;
        }

        input:focus {
            border-color: #1f3c68;
            outline: 2px solid #c5d5eb;
        }

        button {
            width: 100%;
            margin-top: 10px;
            padding: 12px;
            border: none;
            border-radius: 5px;
            background-color: #1f3c68;
            color: white;
            font-size: 17px;
            cursor: pointer;
        }

        button:hover {
            background-color: #142947;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Student Information Form</h1>

    <p class="instructions">
        Complete every field to generate JSON output.
    </p>

    <form action="WillJSONProcess.php" method="post">

        <div class="form-group">
            <label for="firstName">First Name</label>
            <input type="text"
                   id="firstName"
                   name="firstName"
                   required>
        </div>

        <div class="form-group">
            <label for="lastName">Last Name</label>
            <input type="text"
                   id="lastName"
                   name="lastName"
                   required>
        </div>

        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email"
                   id="email"
                   name="email"
                   required>
        </div>

        <div class="form-group">
            <label for="studentId">Student ID</label>
            <input type="text"
                   id="studentId"
                   name="studentId"
                   required>
        </div>

        <div class="form-group">
            <label for="major">Major</label>
            <input type="text"
                   id="major"
                   name="major"
                   required>
        </div>

        <div class="form-group">
            <label for="course">Course</label>
            <input type="text"
                   id="course"
                   name="course"
                   required>
        </div>

        <div class="form-group">
            <label for="city">City</label>
            <input type="text"
                   id="city"
                   name="city"
                   required>
        </div>

        <div class="form-group">
            <label for="state">State</label>
            <input type="text"
                   id="state"
                   name="state"
                   required>
        </div>

        <div class="form-group">
            <label for="language">
                Favorite Programming Language
            </label>

            <input type="text"
                   id="language"
                   name="language"
                   required>
        </div>

        <div class="form-group">
            <label for="experience">
                Years of Programming Experience
            </label>

            <input type="number"
                   id="experience"
                   name="experience"
                   min="0"
                   required>
        </div>

        <button type="submit">Create JSON Output</button>

    </form>

</div>

</body>
</html>