<?php
/*
    Name: Will Cotton
    Course: CSD 440 - Server-Side Scripting
    Assignment: Module 10 JSON Form
    Date: September 26, 2026
    File: WillJSONProcess.php


*/

$errorMessage = "";
$jsonOutput = "";

// Verify that the form used the POST method.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // List of fields required from WillJSONForm.php.
    $requiredFields = [
        "firstName",
        "lastName",
        "email",
        "studentId",
        "major",
        "course",
        "city",
        "state",
        "language",
        "experience"
    ];

    // Check that each required field contains a value.
    foreach ($requiredFields as $field) {
        if (!isset($_POST[$field]) ||
            trim($_POST[$field]) === "") {

            $errorMessage =
                "Submission failed. Please complete every field.";

            break;
        }
    }

    // Validate the email address.
    if ($errorMessage === "" &&
        !filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {

        $errorMessage =
            "Submission failed. Please enter a valid email address.";
    }

    // Validate years of programming experience.
    if ($errorMessage === "" &&
        (!is_numeric($_POST["experience"]) ||
         (int) $_POST["experience"] < 0)) {

        $errorMessage =
            "Programming experience must be zero or greater.";
    }

    // Build and encode the data when validation succeeds.
    if ($errorMessage === "") {

        $formData = [
            "firstName" =>
                trim($_POST["firstName"]),

            "lastName" =>
                trim($_POST["lastName"]),

            "email" =>
                trim($_POST["email"]),

            "studentId" =>
                trim($_POST["studentId"]),

            "major" =>
                trim($_POST["major"]),

            "course" =>
                trim($_POST["course"]),

            "city" =>
                trim($_POST["city"]),

            "state" =>
                trim($_POST["state"]),

            "favoriteProgrammingLanguage" =>
                trim($_POST["language"]),

            "yearsOfProgrammingExperience" =>
                (int) $_POST["experience"]
        ];

        $jsonOutput = json_encode(
            $formData,
            JSON_PRETTY_PRINT
        );

        if ($jsonOutput === false) {
            $errorMessage =
                "The submitted data could not be encoded into JSON.";
        }
    }

} else {
    $errorMessage =
        "Invalid request. Please submit the student form first.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>JSON Form Results</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px;
            font-family: Arial, sans-serif;
            background-color: #eef2f7;
        }

        .container {
            max-width: 750px;
            margin: auto;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        h1 {
            margin-top: 0;
            color: #1f3c68;
            text-align: center;
        }

        .success {
            padding: 14px;
            color: #155724;
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
        }

        .error {
            padding: 14px;
            color: #721c24;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
        }

        pre {
            padding: 20px;
            overflow-x: auto;
            color: #ffffff;
            background-color: #202938;
            border-radius: 6px;
            font-size: 15px;
            line-height: 1.5;
        }

        .return-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 16px;
            color: white;
            background-color: #1f3c68;
            border-radius: 5px;
            text-decoration: none;
        }

        .return-link:hover {
            background-color: #142947;
        }
    </style>
</head>

<body>

<div class="container">

    <?php if ($errorMessage !== ""): ?>

        <h1>Submission Error</h1>

        <div class="error">
            <?php
            echo htmlspecialchars(
                $errorMessage,
                ENT_QUOTES,
                "UTF-8"
            );
            ?>
        </div>

    <?php else: ?>

        <h1>JSON Form Results</h1>

        <p class="success">
            The submitted information was successfully
            encoded into JSON format.
        </p>

        <pre><?php
        echo htmlspecialchars(
            $jsonOutput,
            ENT_QUOTES,
            "UTF-8"
        );
        ?></pre>

    <?php endif; ?>
        <button type="button" class="return-link" onclick="window.location.href='WillJSONForm.php'">Back</button>



</body>
</html>