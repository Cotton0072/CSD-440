<?php
/**
 * sumTwoNumbers
 * 
 * Takes two random numbers and returns their sum.
 * This function will be used by WillTable3.php.
 *
 * @param int $a First random number
 * @param int $b Second random number
 * @return int Sum of both numbers
 */
function sumTwoNumbers($a, $b) {
    return $a + $b;
}
?>
