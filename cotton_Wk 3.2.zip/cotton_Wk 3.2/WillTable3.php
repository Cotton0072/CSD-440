<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Will Table 3</title>
</head>
<body>

<h1>Will Table 3 – Random Sum Table</h1>

<?php
// Include external function file
require_once "sumFunctions.php";

// Set table size (example: 5x5)
$rows = 5;
$cols = 5;

echo "<table border='1' cellpadding='8' cellspacing='0'>";

for ($r = 1; $r <= $rows; $r++) {
    echo "<tr>";
    for ($c = 1; $c <= $cols; $c++) {

        // Generate two random numbers
        $num1 = rand(1, 50);
        $num2 = rand(1, 50);

        // Call function from external file
        $sum = sumTwoNumbers($num1, $num2);

        // Display cell value
        echo "<td>{$num1} + {$num2} = {$sum}</td>";
    }
    echo "</tr>";
}

echo "</table>";
?>

</body>
</html>
